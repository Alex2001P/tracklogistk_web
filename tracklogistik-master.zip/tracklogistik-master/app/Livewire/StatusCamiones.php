<?php

namespace App\Livewire;

use Livewire\Component;

class StatusCamiones extends Component
{
    public function render()
    {
        return view('livewire.status-camiones');
    }
}

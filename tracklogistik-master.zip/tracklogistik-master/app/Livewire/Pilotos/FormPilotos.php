<?php

namespace App\Livewire\Pilotos;

use Livewire\Component;
use App\Models\PilotosModel;
use App\Models\StatusPiloto;
class FormPilotos extends Component
{
    public $name;
    public $lastname;
    public $telefono;
    public $confirmCreatePiloto = false;
    public $selectedOption = null;
    public $options = [];

    public function mount()
    {
        $this->options = StatusPiloto::all()->pluck('name', 'status_id')->toArray();
    }

    public function onOpenModal() {
        $this->confirmCreatePiloto = true;
    }


    public function render()
    {
        return view('livewire.pilotos.form-pilotos');
    }

    public function save()
    {
        PilotosModel::create([
            'name' => $this->name,
            'lastname' => $this->lastname,
            'telefono' => $this->telefono,
            'status_id' => $this->selectedOption,
        ]);

        return redirect()->to('/pilotos')
            ->with('status', 'Piloto Creado!');
    }
}

<?php

use Illuminate\Support\Facades\Route;
use App\Livewire\StatusPilotosController;
use App\Livewire\Camiones;
use App\Livewire\Pilotos;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');


    //Pilotos
    Route::get('/pilotos', function () {
        return view('livewire.pilotos');
    })->name('pilotos');

    Route::get('/status_pilotos', function () {
        return view('livewire.status-pilotos');
    })->name('status_pilotos');

    Route::get('/statusPilotos', StatusPilotosController::class);
    Route::get('/pilotosView', Pilotos::class);

    //Camiones
    Route::get('/status_camiones', function () {
        return view('livewire.status-camiones');
    })->name('status_camiones');

    Route::get('/camiones', function () {
        return view('livewire.camiones');
    })->name('camiones');

    Route::get('/camionesView', Camiones::class);
});


